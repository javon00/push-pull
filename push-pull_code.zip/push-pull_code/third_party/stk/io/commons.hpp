#ifndef __STK_IO_COMMONS__
#define __STK_IO_COMMONS__

namespace stk
{

namespace io
{

enum FileType
{
	Png,
	Dat,
	Pts
};

}

}

#endif
