#ifndef __STK_TYPE__
#define __STK_TYPE__

#include <complex>
//~ #include <cstdint>

namespace stk
{

typedef std::complex<double> Complexd;

}

#endif
