#ifndef __STK_CONSTANT__
#define __STK_CONSTANT__


#define PI 3.141592653589793238462643


#endif
